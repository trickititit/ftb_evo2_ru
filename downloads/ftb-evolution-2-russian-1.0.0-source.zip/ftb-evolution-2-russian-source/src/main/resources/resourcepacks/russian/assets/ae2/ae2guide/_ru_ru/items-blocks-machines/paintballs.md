---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: "Пейнтболы"
  icon: green_lumen_paint_ball
  position: 410
categories:
- tools
item_ids:
- ae2:white_paint_ball
- ae2:orange_paint_ball
- ae2:magenta_paint_ball
- ae2:light_blue_paint_ball
- ae2:yellow_paint_ball
- ae2:lime_paint_ball
- ae2:pink_paint_ball
- ae2:gray_paint_ball
- ae2:light_gray_paint_ball
- ae2:cyan_paint_ball
- ae2:purple_paint_ball
- ae2:blue_paint_ball
- ae2:brown_paint_ball
- ae2:green_paint_ball
- ae2:red_paint_ball
- ae2:black_paint_ball
- ae2:white_lumen_paint_ball
- ae2:orange_lumen_paint_ball
- ae2:magenta_lumen_paint_ball
- ae2:light_blue_lumen_paint_ball
- ae2:yellow_lumen_paint_ball
- ae2:lime_lumen_paint_ball
- ae2:pink_lumen_paint_ball
- ae2:gray_lumen_paint_ball
- ae2:light_gray_lumen_paint_ball
- ae2:cyan_lumen_paint_ball
- ae2:purple_lumen_paint_ball
- ae2:blue_lumen_paint_ball
- ae2:brown_lumen_paint_ball
- ae2:green_lumen_paint_ball
- ae2:red_lumen_paint_ball
- ae2:black_lumen_paint_ball
---

# <a name="paintballs" />Пейнтболы

<Row gap="-8">
  <ItemImage id="white_paint_ball" scale="4" />

  <ItemImage id="orange_paint_ball" scale="4" />

  <ItemImage id="green_paint_ball" scale="4" />

  <ItemImage id="blue_paint_ball" scale="4" />

  <ItemImage id="red_paint_ball" scale="4" />
</Row>

Пейнтбольные шары используются в цифре <ItemLink id="color_applicator" /> для раскрашивания цветных блоков, таких как [кабели](cables.md), шерсти, терракоты, стекла и бетона. Их также можно использовать в режиме <ItemLink id="matter_cannon" /> для съемки небольших пятен краски.

## <a name="recipes" />Рецепты

8 шариков материи вокруг красителя

<Column>
  <Row>
    <RecipeFor id="white_paint_ball" />

    <RecipeFor id="orange_paint_ball" />

    <RecipeFor id="green_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_paint_ball" />

    <RecipeFor id="red_paint_ball" />

    <RecipeFor id="black_paint_ball" />
  </Row>

  <br />
</Column>

# <a name="lumen-paintballs" />Люмен Пейнтболы

<Row gap="-8">
  <ItemImage id="white_lumen_paint_ball" scale="4" />

  <ItemImage id="orange_lumen_paint_ball" scale="4" />

  <ItemImage id="green_lumen_paint_ball" scale="4" />

  <ItemImage id="blue_lumen_paint_ball" scale="4" />

  <ItemImage id="red_lumen_paint_ball" scale="4" />
</Row>

Они действуют идентично обычным пейнтбольным шарам, но пятна излучают свет при выстреле из точки <ItemLink id="matter_cannon" />. Думаю, пригодится как своего рода сигнальный пистолет.

## <a name="recipes" />Рецепты

8 пейнтбольных шаров вокруг светящейся пыли

<Column>
  <Row>
    <RecipeFor id="white_lumen_paint_ball" />

    <RecipeFor id="orange_lumen_paint_ball" />

    <RecipeFor id="green_lumen_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_lumen_paint_ball" />

    <RecipeFor id="red_lumen_paint_ball" />

    <RecipeFor id="black_lumen_paint_ball" />
  </Row>
</Column>
