---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: "Кварцевое стекло"
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# <a name="quartz-glass" />Кварцевое стекло

<BlockImage id="quartz_glass" scale="8" />

В основном прозрачное стекло, изготовленное с помощью <ItemLink id="certus_quartz_dust" />. Используется для изготовления многих машин и предметов AE2.

Существует вариант — яркое кварцевое стекло, излучающее свет.

## <a name="recipes" />Рецепты

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
