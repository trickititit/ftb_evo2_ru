---
navigation:
  parent: appflux/appflux-index.md
  title: "Индукционная карта"
  icon: appflux:induction_card
categories:
- flux accessor
item_ids:
- appflux:induction_card
---

# <a name="induction-card" />Индукционная карта

<Row>
<ItemImage id="appflux:induction_card" scale="4"></ItemImage>
</Row>

Индукционная карта может превратить <ItemLink id="ae2:pattern_provider" /> или <ItemLink id="ae2:interface" /> в 
<ItemLink id="appflux:flux_accessor" />, что позволяет им вводить/выводить энергию.
